#include "main.h"
#include "restaurant.cpp"

int main(int argc, char *argv[])
{
    // string fileName = "test_demo_input.txt";
    string fileName = "test.txt";
    simulate(fileName);

    return 0;
}
